
package logica;

import igu.Pantalla;


public class PruebaCapas {

    
    public static void main(String[] args) {
        Pantalla panta= new Pantalla();
       panta.setVisible(true);
       
       panta.setLocationRelativeTo(null);
       
    }
    
}
