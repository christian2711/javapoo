
package clasesabstractas;


public interface Dibujable {
   public void dibujar();
   
}
