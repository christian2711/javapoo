
package clasesabstractas;


public interface rotable {
    public void rotar();
    
}
