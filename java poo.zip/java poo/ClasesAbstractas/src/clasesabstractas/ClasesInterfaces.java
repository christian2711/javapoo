
package clasesabstractas;


public class ClasesInterfaces {

  
    public static void main(String[] args) {
        
        Cuadrado cuad1 = new Cuadrado();
        cuad1.dibujar();
       
        
    }
    
}
