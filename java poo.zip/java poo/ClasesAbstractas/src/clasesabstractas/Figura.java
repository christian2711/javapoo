
package clasesabstractas;


public interface  Figura {
    
    public double calculoArea();
    
    
}


