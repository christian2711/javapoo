
package Logica;


public class Scuartl extends Poke implements Iagua {

    public Scuartl() {
    }

    
    
    @Override
    protected void atacarPlacaje() {
         System.out.println("hola soy scuartl y este es mi placaje");
    }

    @Override
    protected void atacarAraniazo() {
         System.out.println("hola soy scuartl y este es mi araniazo");
    }

    @Override
    protected void atacarMordisco() {
         System.out.println("hola soy scuartl y este es mi mordisco");
    }

    @Override
    public void atacarHidrobomba() {
        System.out.println("hola soy scuartl y este es mi hidrobomba");
    }

    @Override
    public void atacarBurbuja() {
        System.out.println("hola soy scuartl y este es mi burbuja");
    }

    @Override
    public void atacraPistolaAgua() {
        System.out.println("hola soy scuartl y este es mi pistola agua");
    }
    
}
