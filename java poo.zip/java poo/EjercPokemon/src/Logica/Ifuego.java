
package Logica;


public interface Ifuego {
    public void atacarPuniofuego();
    public void atacarLanzaLLama();
    public void atacarAscuas();
    
    
}
