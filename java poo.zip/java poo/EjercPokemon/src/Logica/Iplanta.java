
package Logica;


public interface Iplanta {
    public void atacarDrenaje();
    public void atacarParalizar();
    
    
    
    
}
