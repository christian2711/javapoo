package mascotas;

import mascotas.newpackage.Servicio;

public class Mascota {

    public static void main(String[] args) {

        Servicio sm = new Servicio();
        Mascota1 m1 = sm.crearmascota();

        System.out.println(m1);
       
         
       }

    

    

}
