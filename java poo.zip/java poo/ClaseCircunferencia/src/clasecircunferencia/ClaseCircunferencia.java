
package clasecircunferencia;


public class ClaseCircunferencia {

   
    public static void main(String[] args) {
        Circunsferencia circu = new Circunsferencia(2);
        
        circu.area();
        System.out.println("el area de circu es: " + 3.14 * circu.getRadio()*circu.getRadio());
        circu.perimetro();
        System.out.println("el perimetro de circu es: " + 2*3.14*circu.getRadio() );
    }
    
}
